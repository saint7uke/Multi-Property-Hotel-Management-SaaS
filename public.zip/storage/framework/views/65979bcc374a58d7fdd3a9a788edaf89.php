<?php echo value($html); ?>

<?php /**PATH F:\Xampp 8\htdocs\Hotel\vendor\filament\support\resources\views\anonymous-partial.blade.php ENDPATH**/ ?>