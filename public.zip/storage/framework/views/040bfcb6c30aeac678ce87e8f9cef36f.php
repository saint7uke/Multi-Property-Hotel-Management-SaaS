<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'property',
    'image',
    'featured' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'property',
    'image',
    'featured' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<article <?php echo e($attributes->class(['home-property group', 'home-property--featured' => $featured])); ?>>
    <a class="block" href="<?php echo e(route('hotels.show', $property)); ?>" aria-label="View <?php echo e($property->name); ?>">
        <div class="home-property__media">
            <img
                src="<?php echo e($image); ?>"
                alt="Guest experience at <?php echo e($property->name); ?>"
                width="1200"
                height="900"
                loading="lazy"
                decoding="async"
            >
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($property->offers_breakfast): ?>
                <span class="home-property__flag">Breakfast available</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="home-property__body">
            <div>
                <p class="home-kicker"><?php echo e($property->city); ?>, <?php echo e($property->country); ?></p>
                <h3><?php echo e($property->name); ?></h3>
                <p><?php echo e($property->tagline ?: $property->address); ?></p>
            </div>
            <span class="home-text-link" aria-hidden="true">View property <span>→</span></span>
        </div>
    </a>
</article>
<?php /**PATH F:\Xampp 8\htdocs\Hotel\resources\views/components/public/property-card.blade.php ENDPATH**/ ?>