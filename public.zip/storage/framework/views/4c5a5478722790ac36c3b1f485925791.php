<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['review']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['review']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<article <?php echo e($attributes->class('home-review')); ?>>
    <div class="flex items-center justify-between gap-4">
        <p class="home-kicker">Verified guest</p>
        <p class="home-review__rating" aria-label="Rated <?php echo e($review->rating); ?> out of 5"><?php echo e($review->rating); ?>/5</p>
    </div>
    <blockquote>&ldquo;<?php echo e($review->message); ?>&rdquo;</blockquote>
    <footer>
        <p><?php echo e($review->guest->name); ?></p>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($review->property): ?>
            <span><?php echo e($review->property->name); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </footer>
</article>
<?php /**PATH F:\Xampp 8\htdocs\Hotel\resources\views/components/public/review-card.blade.php ENDPATH**/ ?>