<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Staff Sign In | M.A Group of Hotels</title>
    <?php if (isset($component)) { $__componentOriginala73f6e71309033d591ec874fb5b75f3c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala73f6e71309033d591ec874fb5b75f3c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.brand.favicon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand.favicon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala73f6e71309033d591ec874fb5b75f3c)): ?>
<?php $attributes = $__attributesOriginala73f6e71309033d591ec874fb5b75f3c; ?>
<?php unset($__attributesOriginala73f6e71309033d591ec874fb5b75f3c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala73f6e71309033d591ec874fb5b75f3c)): ?>
<?php $component = $__componentOriginala73f6e71309033d591ec874fb5b75f3c; ?>
<?php unset($__componentOriginala73f6e71309033d591ec874fb5b75f3c); ?>
<?php endif; ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/staff-auth.ts']); ?>
</head>
<body class="premium-auth" data-staff-auth>
    <img
        class="premium-auth__image"
        src="<?php echo e(asset('images/home/property-lobby.jpg')); ?>"
        alt=""
        width="1600"
        height="1067"
        fetchpriority="high"
    >
    <div class="premium-auth__scrim" aria-hidden="true"></div>

    <main class="premium-auth__shell">
        <a class="premium-auth__brand" href="<?php echo e(route('home')); ?>" aria-label="M.A Group of Hotels home">
            <?php if (isset($component)) { $__componentOriginal01ddce07fdfaa1771f1dfaf8e4a4294b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal01ddce07fdfaa1771f1dfaf8e4a4294b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.brand.logo','data' => ['class' => 'premium-auth__brand-logo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'premium-auth__brand-logo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal01ddce07fdfaa1771f1dfaf8e4a4294b)): ?>
<?php $attributes = $__attributesOriginal01ddce07fdfaa1771f1dfaf8e4a4294b; ?>
<?php unset($__attributesOriginal01ddce07fdfaa1771f1dfaf8e4a4294b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01ddce07fdfaa1771f1dfaf8e4a4294b)): ?>
<?php $component = $__componentOriginal01ddce07fdfaa1771f1dfaf8e4a4294b; ?>
<?php unset($__componentOriginal01ddce07fdfaa1771f1dfaf8e4a4294b); ?>
<?php endif; ?>
        </a>

        <section class="premium-auth__copy" data-auth-copy aria-labelledby="staff-welcome">
            <p class="premium-kicker">Staff operations</p>
            <h1 id="staff-welcome">One secure entrance to your workspace.</h1>
            <p>Your account opens the correct hotel operations panel automatically, with access limited to your assigned role and property.</p>
            <span class="premium-auth__note">Authorized personnel only</span>
        </section>

        <section class="premium-auth__form" data-auth-form aria-labelledby="sign-in-title">
            <p class="premium-kicker">Secure staff access</p>
            <h2 id="sign-in-title">Sign in</h2>
            <p class="premium-auth__intro">Use the staff account issued by your system administrator or hotel manager.</p>

            <form class="mt-7 grid gap-5" method="POST" action="<?php echo e(route('staff.authenticate')); ?>">
                <?php echo csrf_field(); ?>

                <label class="grid gap-2" for="email">
                    <span class="ma-label">Email address</span>
                    <input
                        id="email"
                        class="ma-input"
                        type="email"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        autocomplete="username"
                        inputmode="email"
                        required
                        autofocus
                    >
                </label>

                <label class="grid gap-2" for="password">
                    <span class="ma-label">Password</span>
                    <input
                        id="password"
                        class="ma-input"
                        type="password"
                        name="password"
                        autocomplete="current-password"
                        minlength="8"
                        required
                    >
                </label>

                <label class="flex min-h-11 items-center gap-3 font-sans text-sm font-medium text-[#26334a]">
                    <input class="h-4 w-4 accent-[#111d32]" type="checkbox" name="remember" value="1">
                    <span>Keep me signed in on this device</span>
                </label>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                    <div class="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800" role="alert">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <button class="premium-button premium-button--navy w-full" type="submit">Sign in securely</button>
            </form>

            <div class="premium-auth__help">
                <a href="<?php echo e(route('home')); ?>">Back to website</a>
                <span>Need access? Contact your manager.</span>
            </div>
        </section>
    </main>
</body>
</html>
<?php /**PATH F:\Xampp 8\htdocs\Hotel\resources\views\auth\staff-sign-in.blade.php ENDPATH**/ ?>