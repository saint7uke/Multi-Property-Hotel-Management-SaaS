<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'class' => '',
    'loading' => 'eager',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'class' => '',
    'loading' => 'eager',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<img
    src="<?php echo e(asset('MALogo.png')); ?>"
    alt="M.A Group of Hotels"
    width="500"
    height="500"
    loading="<?php echo e($loading); ?>"
    decoding="async"
    <?php echo e($attributes->class(['ma-global-logo', $class])); ?>

>
<?php /**PATH F:\Xampp 8\htdocs\Hotel\resources\views\components\brand\logo.blade.php ENDPATH**/ ?>