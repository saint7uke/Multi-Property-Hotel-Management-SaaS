<p
    <?php echo e($attributes->class(['fi-modal-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH F:\Xampp 8\htdocs\Hotel\vendor\filament\support\resources\views\components\modal\description.blade.php ENDPATH**/ ?>