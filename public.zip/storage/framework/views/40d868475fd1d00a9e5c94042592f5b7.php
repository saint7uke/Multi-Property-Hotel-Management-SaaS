<link rel="icon" type="image/png" href="<?php echo e(asset('MALogo.png')); ?>">
<link rel="apple-touch-icon" href="<?php echo e(asset('MALogo.png')); ?>">
<?php /**PATH F:\Xampp 8\htdocs\Hotel\resources\views/components/brand/favicon.blade.php ENDPATH**/ ?>