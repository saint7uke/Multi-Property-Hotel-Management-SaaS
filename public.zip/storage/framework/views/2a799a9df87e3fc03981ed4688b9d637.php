<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'copy',
    'image',
    'alt',
    'eyebrow' => null,
    'compact' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'copy',
    'image',
    'alt',
    'eyebrow' => null,
    'compact' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section <?php echo e($attributes->class(['premium-hero', 'premium-hero--compact' => $compact])); ?> data-premium-hero>
    <img
        class="premium-hero__image"
        src="<?php echo e($image); ?>"
        alt="<?php echo e($alt); ?>"
        width="2000"
        height="1200"
        fetchpriority="high"
        decoding="async"
        data-premium-hero-image
    >
    <div class="premium-hero__scrim" aria-hidden="true"></div>
    <div class="premium-shell premium-hero__inner">
        <div class="premium-hero__copy" data-premium-hero-copy>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($eyebrow): ?>
                <p class="premium-kicker"><?php echo e($eyebrow); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <h1><?php echo e($title); ?></h1>
            <p><?php echo e($copy); ?></p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($actions)): ?>
                <div class="premium-hero__actions"><?php echo e($actions); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH F:\Xampp 8\htdocs\Hotel\resources\views\components\public\page-hero.blade.php ENDPATH**/ ?>