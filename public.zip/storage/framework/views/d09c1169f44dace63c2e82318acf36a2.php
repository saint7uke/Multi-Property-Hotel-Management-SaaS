<?php echo e(\Filament\Support\generate_loading_indicator_html($attributes)); ?>

<?php /**PATH F:\Xampp 8\htdocs\Hotel\vendor\filament\support\resources\views\components\loading-indicator.blade.php ENDPATH**/ ?>