<?php $__env->startSection('content'); ?>
    <?php
        $posts = [
            [
                'title' => 'How to Plan a Comfortable Staycation with M.A Group of Hotels',
                'category' => 'Guest Tips',
                'read' => '2 min read',
                'excerpt' => 'Choose the right room, plan nearby meals, and give yourself enough time to enjoy the hotel spaces.',
                'image' => asset('images/home/property-suite.jpg'),
                'day' => '24',
                'month' => 'May',
            ],
            [
                'title' => 'Room Reservation Guide for First-Time Guests',
                'category' => 'Booking',
                'read' => '3 min read',
                'excerpt' => 'A simple walkthrough of property selection, available rooms, guest details, and reference number tracking.',
                'image' => asset('images/home/journey-personal.jpg'),
                'day' => '18',
                'month' => 'Jun',
            ],
            [
                'title' => 'Celebrate Special Moments in a Premium Hotel Setting',
                'category' => 'Celebrations',
                'read' => '2 min read',
                'excerpt' => 'From family gatherings to group requests, event bookings help staff review space needs before pricing.',
                'image' => asset('images/home/journey-event.jpg'),
                'day' => '07',
                'month' => 'Jul',
            ],
        ];
    ?>

<div class="premium-page">
    <?php if (isset($component)) { $__componentOriginal7667e390c55120bda1fc27c0189959e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7667e390c55120bda1fc27c0189959e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public.page-hero','data' => ['eyebrow' => 'Stories and guest guide','title' => 'Stories & Guest Guide - Hotel Journal','copy' => 'Hotel stories, guest guides, stay reminders, and event updates for M.A Group of Hotels guests.','image' => asset('images/home/property-resort.jpg'),'alt' => 'M.A resort destination and travel journal setting','compact' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'Stories and guest guide','title' => 'Stories & Guest Guide - Hotel Journal','copy' => 'Hotel stories, guest guides, stay reminders, and event updates for M.A Group of Hotels guests.','image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset('images/home/property-resort.jpg')),'alt' => 'M.A resort destination and travel journal setting','compact' => true]); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <a class="premium-button premium-button--gold" href="#journal">Browse journal</a>
            <a class="premium-button premium-button--ghost" href="<?php echo e(route('book.now')); ?>">Plan a stay</a>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7667e390c55120bda1fc27c0189959e9)): ?>
<?php $attributes = $__attributesOriginal7667e390c55120bda1fc27c0189959e9; ?>
<?php unset($__attributesOriginal7667e390c55120bda1fc27c0189959e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7667e390c55120bda1fc27c0189959e9)): ?>
<?php $component = $__componentOriginal7667e390c55120bda1fc27c0189959e9; ?>
<?php unset($__componentOriginal7667e390c55120bda1fc27c0189959e9); ?>
<?php endif; ?>

    <section id="journal" class="premium-section bg-white">
        <div class="premium-shell">
            <div class="premium-heading-row" data-premium-reveal>
                <?php if (isset($component)) { $__componentOriginalbaa743f42bd8f038a8bb1a3760c8d3be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbaa743f42bd8f038a8bb1a3760c8d3be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public.page-section-heading','data' => ['eyebrow' => 'Latest notes','title' => 'Thoughtful guidance for easier stays.','copy' => 'Practical booking notes, room guidance, and celebration ideas for every kind of M.A guest.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.page-section-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'Latest notes','title' => 'Thoughtful guidance for easier stays.','copy' => 'Practical booking notes, room guidance, and celebration ideas for every kind of M.A guest.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbaa743f42bd8f038a8bb1a3760c8d3be)): ?>
<?php $attributes = $__attributesOriginalbaa743f42bd8f038a8bb1a3760c8d3be; ?>
<?php unset($__attributesOriginalbaa743f42bd8f038a8bb1a3760c8d3be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbaa743f42bd8f038a8bb1a3760c8d3be)): ?>
<?php $component = $__componentOriginalbaa743f42bd8f038a8bb1a3760c8d3be; ?>
<?php unset($__componentOriginalbaa743f42bd8f038a8bb1a3760c8d3be); ?>
<?php endif; ?>
                <form class="w-full max-w-sm" data-journal-search role="search">
                    <label class="ma-label" for="journal-search">Search journal</label>
                    <div class="mt-2 flex gap-2">
                        <input id="journal-search" class="ma-input" type="search" name="search" placeholder="Search posts">
                        <button class="premium-button premium-button--navy" type="submit">Search</button>
                    </div>
                    <p class="mt-2 min-h-5 text-sm text-black/55" data-journal-feedback aria-live="polite"></p>
                </form>
            </div>

            <div class="mt-12 grid gap-8 lg:grid-cols-[1fr_18rem]">
                <div class="grid gap-6 md:grid-cols-2" data-premium-stagger>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article
                            class="group <?php echo e($loop->first ? 'md:col-span-2 md:grid md:grid-cols-[1.15fr_.85fr]' : ''); ?> overflow-hidden border border-[#d9dee6] bg-white"
                            data-journal-post
                            data-search-text="<?php echo e(strtolower($post['title'].' '.$post['category'].' '.$post['excerpt'])); ?>"
                        >
                            <div class="premium-media relative <?php echo e($loop->first ? 'aspect-[16/10] md:aspect-auto' : 'aspect-[16/10]'); ?> rounded-none">
                                <img src="<?php echo e($post['image']); ?>" alt="<?php echo e($post['title']); ?>" width="1200" height="800" loading="lazy" decoding="async">
                                <time class="absolute left-4 top-4 rounded-sm bg-[#d4a24c] px-3 py-2 text-center font-sans text-xs font-semibold leading-tight text-[#111d32]"><?php echo e($post['day']); ?><br><?php echo e($post['month']); ?></time>
                            </div>
                            <div class="flex flex-col justify-center p-6 lg:p-8">
                                <p class="premium-kicker"><?php echo e($post['category']); ?> &middot; <?php echo e($post['read']); ?></p>
                                <h2 class="mt-3 text-2xl font-medium leading-tight text-ma-blue <?php echo e($loop->first ? 'lg:text-3xl' : ''); ?>"><?php echo e($post['title']); ?></h2>
                                <p class="mt-4 text-sm leading-7 text-black/62"><?php echo e($post['excerpt']); ?></p>
                                <a class="premium-text-link mt-6" href="<?php echo e(route('contact')); ?>">Read More <span>&rarr;</span></a>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="hidden border border-[#d9dee6] p-6 md:col-span-2" data-journal-empty>
                        <h2 class="text-xl font-medium text-ma-blue">No journal articles found.</h2>
                        <p class="mt-2 text-sm text-black/60">Try a broader topic such as booking, rooms, or celebrations.</p>
                    </div>
                </div>

                <aside class="content-start lg:sticky lg:top-28 lg:self-start" data-premium-reveal>
                    <section class="border-t border-[#d9dee6] py-5">
                        <h2 class="text-lg font-medium text-ma-blue">Recent Posts</h2>
                        <ol class="premium-rule-list mt-3">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-sm font-semibold leading-6 text-black/68"><?php echo e($post['title']); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </ol>
                    </section>
                    <section class="border-t border-[#d9dee6] py-5">
                        <p class="premium-kicker">Featured Stay</p>
                        <h2 class="mt-2 text-xl font-medium text-ma-blue">Family Room</h2>
                        <p class="mt-3 text-sm leading-6 text-black/60">Space to rest, reconnect, and settle into a comfortable family visit.</p>
                        <a class="premium-text-link mt-5" href="<?php echo e(route('book.now')); ?>">Book Now <span>&rarr;</span></a>
                    </section>
                </aside>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', [
    'title' => 'Stories & Guest Guide - Hotel Journal',
    'description' => 'Hotel stories, booking guidance, and stay planning notes from M.A Group of Hotels.',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Xampp 8\htdocs\Hotel\resources\views\public\blog.blade.php ENDPATH**/ ?>